#ifndef COMPLEXNUMBER_H // Um Mehrfachdefinition auszuschlie�en!
#define COMPLEXNUMBER_H

class ComplexNumber {

public:

	//Default constructor
	//ComplexNumber() {

	//}
	
	//Generic constructor with default parameters (task 2)
	ComplexNumber(bool isCartesian, double a = 2.0, double b = 5.0);

	//Constructor for complex number with an initialization list for cartesian (task 3)
	ComplexNumber(double a, double b);

	~ComplexNumber();

	//Setter for each coordinate and the form
	void setCartesianCoords(double a, double b);
	void setPolarCoords(double r, double phi);
	void setRealPart(double a);
	void setImaginaryPart(double b);
	void setRadius(double r);
	void setAngle(double phi);

	//Getter for each coordinate
	double getRealPart() const { return m_a; }
	double getImaginaryPart() const { return m_b; }
	double getRadius() const { return m_r; }
	double getAngle() const { return m_phi; }

	std::string toCartesianString() const;
	std::string toPolarString() const;
	std::string toString() const;

	static int amountComplexNumbers;
	ComplexNumber operator*(const ComplexNumber& otherComplexNumber) const;

private:

	double m_a, m_b, m_r, m_phi;

	void calculateRealPart();
	void calculateImaginaryPart();
	void calculateRadius();
	void calculateAngle();

};

#endif
