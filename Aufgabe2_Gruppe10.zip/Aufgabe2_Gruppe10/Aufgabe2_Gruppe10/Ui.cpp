#include <stdio.h>
#include <iostream>
using namespace std;
#include "ComplexNumber.h"
#include <string>
#include "Ui.h"

void Ui::run() {

	ComplexNumber cN1(true, 5.0, 2.0), cN2(false, 3.6, 43.0);
	char input;

	std::cout << "If you want to enter real and imaginary part type 'a' or 'b' for radius and angle.";
	scanf_s("%c", &input, 1);

	if (input == 'a') {
		double realpart;
		double imaginarypart;
		std::cout << "Enter real part: ";
		scanf_s("%lf", &realpart);
		std::cout << "Enter imaginary part: ";
		scanf_s("%lf", &imaginarypart);
		cN1.setCartesianCoords(realpart, imaginarypart);
		std::cout << cN1.toPolarString() << endl;
		std::cout << cN1.toString() << endl;
	}
	else if (input == 'b') {
		double radius;
		double angle;
		std::cout << "Enter radius: ";
		scanf_s("%lf", &radius);
		std::cout << "Enter angle: ";
		scanf_s("%lf", &angle);
		cN2.setPolarCoords(radius, angle);
		std::cout << cN2.toCartesianString() << endl;
		std::cout << cN2.toString() << endl;
	}

	//Called by constructor with initialization list
	ComplexNumber *cpN = new ComplexNumber(3.0, 4.0);
	delete cpN;

	//Added constructor in ComplexNumber.h
	ComplexNumber number(false, 3.0, 55.0);
	std::cout << "ComplexNumber1 called by constructor: " << number.toString() << endl;

	//Multiple numbers with different default parameters
	ComplexNumber number2(true);
	std::cout << "ComplexNumber2 called by constructor with one parameter: " << number2.toString() << endl;
	ComplexNumber number3(true, 3.0);
	std::cout << "ComplexNumber3 called by constructor with two parameters: " << number3.toString() << endl;
	ComplexNumber number4(false, 3.5, 1.75);
	std::cout << "ComplexNumber4 called by constructor with three parameters: " << number4.toString() << endl;

	//Wird mitgez�hlt
	ComplexNumber a(1.0, -2.0);
	//Wird nicht mitgez�hlt, da b kein neues Objekt ist.
	ComplexNumber b(a);

	ComplexNumber mCP1(3.0, 0.0);
	ComplexNumber mCP2(3.0, 4.0);
	ComplexNumber mResult = mCP1 * mCP2;
	std::cout << mResult.toString() << endl;

	std::cout << ComplexNumber::amountComplexNumbers << endl;

}