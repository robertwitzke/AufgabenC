#include <string>

class MatrixException {
public:
	MatrixException(const std::string& className, const std::string& reason) : m_className(className), m_reason(reason) { }
	std::string getError() const {
		return "Klasse \"" + m_className + "\" weist einen Fehler auf!\n"
			"Grund: " + m_reason;
	}
private:
	std::string m_className;
	std::string m_reason;

};
