#ifndef Matrix3
#define Matrix3

#include <string>

class Matrix33
{
public:

    // Static Class-Functions
    static Matrix33 zeros();
    static Matrix33 ones();

    // Construction
    Matrix33(double m11, double ml2, double m13,
        double m21, double m22, double m23,
        double m31, double m32, double m33);

    double& get(int row, int col);

    // Operator overloading
    Matrix33 operator+(const Matrix33& other) const;
    Matrix33 operator+=(const Matrix33& other);
    Matrix33 operator*(const Matrix33& other) const;
    Matrix33 operator*(const int other) const;

    //Umwandlung von Matrix in double f�r die Determinante
    operator double() const {
        return (m_matrix[0][0] * m_matrix[1][1] * m_matrix[2][2] + m_matrix[0][1] * m_matrix[1][2] * m_matrix[2][0] + m_matrix[1][0] * m_matrix[2][1] * m_matrix[0][2])
            - (m_matrix[0][2] * m_matrix[1][1] * m_matrix[2][0] + m_matrix[1][2] * m_matrix[2][1] * m_matrix[0][0] + m_matrix[0][1] * m_matrix[1][0] * m_matrix[2][2]);
    }

    std::string toString() const;

private:
    double m_matrix[3][3];
};

inline Matrix33 operator*(const int self, const Matrix33& other) {
    return other * self;
}

class MatrixDimensionError {
public:
    std::string getError() const {
        return "Die eingegebenen Indizes liegen nicht im Wertebereich der 3x3 Matrix!";
    }

};

#endif
