#ifndef NEGATIVEVALUESEXCEPTION_H
#define NEGATIVEVALUESEXCEPTION_H
#include <string>

class NegativeValuesException {
public:

    std::string getError() const {
        return "Die Werte d�rfen nicht negativ sein!";
    }

};

#endif