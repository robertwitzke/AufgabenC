#include <string>

class InvalidSelectionException {
public:
    std::string getError() const {
        return "Der Wert ist au�erhalb des g�ltigen Bereichs.";
    }
private:

};
