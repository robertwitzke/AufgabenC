#define M_PI acos(-1.0)
#include <string>
#include <sstream>
#include "Graf.h"
#include "Kreis.h"
#include "NegativeValuesException.h"

std::string Kreis::toString() {
	std::stringstream s;
	s << "Koordinaten: (" << m_koordinate.getX() << ", " << m_koordinate.getY()\
	  << "), Radius: " << m_radius << std::endl;
	return s.str();
}

double Kreis::calculateArea() {
	return M_PI * m_radius * m_radius;
}

void Kreis::setRadius(double radius) {
	if (radius <= 0) {
		throw NegativeValuesException();
	}
	else {
		m_radius = radius;
	}
}

void Kreis::setCoords(Koordinate koordinate) {
	m_koordinate = koordinate;
}