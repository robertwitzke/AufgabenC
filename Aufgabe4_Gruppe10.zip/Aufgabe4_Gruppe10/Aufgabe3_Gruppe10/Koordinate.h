#ifndef KOORDINATE_H
#define KOORDINATE_H
class Koordinate {
public:

	Koordinate(double x = 0, double y = 0) : m_x(x), m_y(y) {

	}

	double getX() const { return m_x; }
	double getY() const { return m_y; }

private:

	double m_x, m_y;

};

#endif