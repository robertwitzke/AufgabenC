#include <stdio.h>
#include <iostream>
using namespace std;
#include <list>
#include <string>
#include "Graf.h"
#include "NegativeValuesException.h"
#include "InvalidSelectionException.h"
#include "Koordinate.h"
#include "Rechteck.h"
#include "Kreis.h"
#include "Ui.h"

void Ui::run() {
	
	int input, userinput;
	list<Graf*> alleGrafen;
	list<Rechteck> alleRechtecke;
	list<Kreis> alleKreise;

	while (true) {
		std::cout << "Was m�chtest du gerne tun?" << endl;
		std::cout << "1. Zeichenelement erstellen" << endl;
		std::cout << "2. Zeichenelemente anzeigen" << endl;
		std::cout << "3. Programm beenden" << endl;
		scanf_s("%d", &input);

		switch (input) {
			case 1:
				double x, y, radius, width, height;
				std::cout << "Dr�cke 1 f�r die Erstellung eines Kreises, 2 f�r ein Rechteck." << endl;
				scanf_s("%d", &userinput);
				if (userinput == 1) {
					std::cout << "Gib die x-Koordinate ein." << endl;
					scanf_s("%lf", &x);
					std::cout << "Gib die y-Koordinate ein." << endl;
					scanf_s("%lf", &y);
					std::cout << "Gib den Radius ein." << endl;
					scanf_s("%lf", &radius);
					Koordinate koordinate(x, y);
					Kreis kreis;
					try {
						kreis.setCoords(koordinate);
						kreis.setRadius(radius);
						alleKreise.push_back(kreis);
						Kreis* pKreis = &kreis;
						alleGrafen.push_back(pKreis);
						std::cout << kreis.toString() << "area: " << kreis.calculateArea() << endl;
					}
					catch (const NegativeValuesException& e) {
						std::cout << "Exception:\n" << e.getError() << std::endl;
					}
				}
				else if (userinput == 2) {
					std::cout << "Gib die x-Koordinate ein." << endl;
					scanf_s("%lf", &x);
					std::cout << "Gib die y-Koordinate ein." << endl;
					scanf_s("%lf", &y);
					std::cout << "Gib die Breite ein." << endl;
					scanf_s("%lf", &width);
					std::cout << "Gib die H�he ein." << endl;
					scanf_s("%lf", &height);
					Koordinate koordinate(x, y);
					Rechteck rechteck;
					try {
						rechteck.setCoords(koordinate);
						rechteck.setWidth(width);
						rechteck.setHeight(height);
						alleRechtecke.push_back(rechteck);
						Rechteck* pRechteck = &rechteck;
						alleGrafen.push_back(pRechteck);
						std::cout << rechteck.toString() << "area: " << rechteck.calculateArea() << endl;
					}
					catch (const NegativeValuesException& e) {
						std::cout << "Exception:\n" << e.getError() << std::endl;
					}
				}
				else {
					//Exception-Handling
					std::cout << "Fehler." << endl;
					break;
				}
				break;
			case 2:
				std::cout << "Dr�cke 1 f�r eine gemischte Reihenfolge, 2 f�r eine geordnete Reihenfolge." << endl;
				scanf_s("%d", &userinput);
				if (userinput == 1) {
					for (Graf* x : alleGrafen) {
						std::cout << "Objekt: " << (*x).toString() << endl;
					}
				}
				else if (userinput == 2) {
					for (Kreis x : alleKreise) {
						std::cout << "Kreis: " << x.toString() << endl;
					}

					for (Rechteck y : alleRechtecke) {
						std::cout << "Rechteck: " << y.toString() << endl;
					}
				}
				else {
					//Exception-Handling
					std::cout << "Fehler." << endl;
					break;
				}
				break;
			case 3:
				std::cout << "Wiederschauen und Reingehauen" << endl;
				exit(0);
				break;
			default:
				InvalidSelectionException e;
				std::cout << "Exception:\n" << e.getError() << std::endl;
				break;
		}

	}

	Koordinate koordinate;
	Rechteck rechteck1;
	Kreis kreis1;
	std::cout << rechteck1.toString() << "area: " << rechteck1.calculateArea() << endl;
	std::cout << kreis1.toString() << "area: " << kreis1.calculateArea() << endl;

	//Graf* pGraf = &x;
	//Rechteck* pRechteck = static_cast<Rechteck*>(pGraf);
	//std::cout << "Objekt: " << (*pRechteck).toString() << endl;

}