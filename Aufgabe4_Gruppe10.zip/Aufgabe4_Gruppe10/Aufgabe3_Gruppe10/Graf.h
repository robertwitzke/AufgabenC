#ifndef GRAF_H // Um Mehrfachdefinition auszuschlie�en!
#define GRAF_H
#include "Koordinate.h"

class Graf {
public:

	Koordinate m_koordinate;
	Koordinate getKoordinate() const { return m_koordinate; }

	virtual double calculateArea() { return 0; };
	virtual std::string toString() = 0;

protected:
	//Da der Konstruktor f�r Graf im protected Bereich liegt, erben die Kindklassen diesen Konstruktor als protected.
	//Dennnoch kann darauf zugegriffen werden, da protected immer noch im f�r die Kindklassen zug�nglichen Bereich liegt.
	Graf(Koordinate koordinate = (0, 0)) : m_koordinate(koordinate) {

	}

private:

};

#endif