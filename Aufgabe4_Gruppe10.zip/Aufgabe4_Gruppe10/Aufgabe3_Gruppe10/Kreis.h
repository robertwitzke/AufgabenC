#ifndef KREIS_H
#define KREIS_H
#include <string>

class Kreis: public Graf {
public:

	Kreis(Koordinate koordinate = (0, 0), double radius = 1.0) : Graf(koordinate), m_radius(radius) {

	}

	void setRadius(double radius);
	void setCoords(Koordinate koordinate);

	virtual double calculateArea();
	virtual std::string toString();

	double getRadius() const{ return m_radius; }

private:

	double m_radius;

};

#endif