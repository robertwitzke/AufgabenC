#ifndef RECHTECK_H
#define RECHTECK_H
#include <string>

class Rechteck: public Graf {
public:

	Rechteck(Koordinate koordinate = (0, 0), double width = 5, double height = 3) : Graf(koordinate), m_width(width), m_height(height) {

	}

	double getWidth() const { return m_width; }
	double getHeight() const { return m_height; }

	void setWidth(double width);
	void setHeight(double height);
	void setCoords(Koordinate koordinate);

	virtual double calculateArea() {
		return m_width * m_height;
	}

	virtual std::string toString();

private:

	double m_width, m_height;

};

#endif
