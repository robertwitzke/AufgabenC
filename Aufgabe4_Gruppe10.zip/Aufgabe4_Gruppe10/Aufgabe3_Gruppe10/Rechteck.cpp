#include <string>
#include <sstream>
#include "Graf.h"
#include "NegativeValuesException.h"
#include "Rechteck.h"

std::string Rechteck::toString() {
	std::stringstream s;
	s << "Koordinaten: (" << m_koordinate.getX() << ", " << m_koordinate.getY() << "), Width: "
	  << m_width << ", Height: " << m_height << std::endl;
	return s.str();
}

void Rechteck::setWidth(double width) {
	if (width <= 0) {
		throw NegativeValuesException();
	}
	else {
		m_width = width;
	}
}

void Rechteck::setHeight(double height) {
	if (height <= 0) {
		throw NegativeValuesException();
	}
	else {
		m_height = height;
	}
}

void Rechteck::setCoords(Koordinate koordinate) {
	m_koordinate = koordinate;
}