#pragma once
class Ui {
public:
	void run();

private:

};
