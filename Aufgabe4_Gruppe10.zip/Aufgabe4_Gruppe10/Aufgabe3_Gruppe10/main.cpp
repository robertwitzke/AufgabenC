#include <iostream>
#include <string>
#include "Graf.h"
#include "NegativeValuesException.h"
#include "Koordinate.h"
#include "Rechteck.h"
#include "Kreis.h"
#include "Ui.h"

int main() {
	Ui gui;
	gui.run();
	return 0;
}