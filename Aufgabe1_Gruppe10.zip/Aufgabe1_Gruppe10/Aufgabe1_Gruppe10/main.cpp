#include <iostream>
#include <string>
#include "ComplexNumber.h"
#include "Ui.h"

int main() {
	Ui gui;
	gui.run();
	return 0;
}