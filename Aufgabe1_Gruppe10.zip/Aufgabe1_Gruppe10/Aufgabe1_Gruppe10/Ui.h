#pragma once
class Ui {
public:
	void run();

private:
	ComplexNumber cN;

};